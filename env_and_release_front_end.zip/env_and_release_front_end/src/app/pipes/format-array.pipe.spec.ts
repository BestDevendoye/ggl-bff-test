import { FormatArrayPipe } from './format-array.pipe';

describe('FormatArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
