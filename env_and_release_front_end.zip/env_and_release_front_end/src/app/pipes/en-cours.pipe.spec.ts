import { EnCoursPipe } from './en-cours.pipe';

describe('EnCoursPipe', () => {
  it('create an instance', () => {
    const pipe = new EnCoursPipe();
    expect(pipe).toBeTruthy();
  });
});
