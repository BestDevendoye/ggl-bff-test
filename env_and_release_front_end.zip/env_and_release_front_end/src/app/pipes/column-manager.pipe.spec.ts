import { ColumnManagerPipe } from './column-manager.pipe';

describe('ColumnManagerPipe', () => {
  it('create an instance', () => {
    const pipe = new ColumnManagerPipe();
    expect(pipe).toBeTruthy();
  });
});
