export enum Profile {
    admin = 'Admin',
    gestionnaire = 'Gestionnaire',
    user = 'Utilisateur'
}
