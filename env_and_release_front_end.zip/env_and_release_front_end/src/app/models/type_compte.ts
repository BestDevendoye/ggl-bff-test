export enum TypeCompte {
    crediteur = 'Créditeur',
    debiteur = 'Débiteur',
}
