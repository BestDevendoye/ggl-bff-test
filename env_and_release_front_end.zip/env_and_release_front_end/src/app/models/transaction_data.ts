import {AdminTransactions} from './admin-transactions';

export interface TransactionData {
    headerRow: string[];
    dataRows: AdminTransactions[];
}
