export enum TaskStatus {
    creation = 'En création',
    pending = 'En cours',
    finished = 'Terminée'
}
