import {User} from './user';

export interface UserData {
    headerRow: string[];
    dataRows: User[];
}
