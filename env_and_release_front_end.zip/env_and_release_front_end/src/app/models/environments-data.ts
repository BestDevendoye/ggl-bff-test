
export const arrayData: any[] = [
    {id: 1, title: 'Fusion datapf et progiciels', class: 'FusionDatapfProgiciels', getFunction: 'getFusionData', saveFunction: 'saveFusionData'},
    {id: 2, title: 'Cartographie DITW & Applications DITW', class: 'CartographieDitw', getFunction: 'getCarts', saveFunction: 'saveCart'}
/*    {id: 2, title: 'Apps_DITW', class: 'AppsDITW'},
    {id: 2, title: 'Apps_AFU', class: 'AppsAFU'},
    {id: 3, title: 'Progiciels_Configuration', class: 'ProgicielConfiguration'},
    {id: 4, title: 'DATA_PF-Configuration', class: 'DataPfConfiguration'},
    {id: 5, title: 'informations serveurs', class: 'InformationServers'},
    {id: 6, title: 'TCD', class: 'Tcd'},
    {id: 7, title: 'TCD data_PF', class: 'TcdDataPf'},
    {id: 8, title: 'Définition', class: 'Definition'},
    {id: 9, title: 'Périmétre-Description', class: 'PerimetreDescription'},
    {id: 10, title: 'Versions du document', class: 'VersionDocument'},
    {id: 11, title: 'Version Applicatif', class: 'VersionApplicatif'},
    {id: 12, title: 'Indisponibilité', class: 'Indisponibilite'}*/
]
