import {AdminTransactions} from './admin-transactions';

export interface EnvironmentDetails {
    headerRow: string[];
    dataRows: AdminTransactions[];
}
