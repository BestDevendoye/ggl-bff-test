export enum StatusTransaction {
    valide = 'Validée',
    refuse = 'Rejetée',
    pending = 'En attente'
}
