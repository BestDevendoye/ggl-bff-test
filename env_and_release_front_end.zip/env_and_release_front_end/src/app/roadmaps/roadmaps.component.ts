import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roadmaps',
  templateUrl: './roadmaps.component.html',
  styleUrls: ['./roadmaps.component.css']
})
export class RoadmapsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
