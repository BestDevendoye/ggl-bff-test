export enum Type {
    Anomalie = 'Anomalie',
  
    Evolution = 'Evolution',

    Incident = 'Incident',

    Recit = 'Recit',

    HorsRelease = 'HorsRelease',
  }