export default () => ({
    appSecret: process.env.APP_SECRET,
});
