export class CreateUserDto {
  nom: string;
  prenom: string;
  tel: string;
  email: string;
  active: boolean;
  password: string;
}
