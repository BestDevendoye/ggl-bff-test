export class UpdateTaskDto {
  title: string;
  description: string;
  planning_id: string;
  status: string;
}
