export class CreateIndisponibilityDto {
  environment: string
  type_indisponibilte: string
  jira: string
  impact_env: string
  delai_correctif: string
}
