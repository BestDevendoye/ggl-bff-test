export class CreatePlanningDto {
  planning_name: string;
  start_date: Date;
  end_date: Date;
}
