export class CreateActivityDto {
  description: string;
  start_date: Date;
  end_date: Date;
}
