export enum Statut {
    FERME,
    OUVERTE,
    CLOTUREE,
    QUALIFICATION,
    RESOLUE
}