export enum Priorite {
    STANDARD,
    EN_URGENCE
}