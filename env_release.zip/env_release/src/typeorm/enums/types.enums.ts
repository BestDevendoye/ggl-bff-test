export enum Types {
    ANOMALIE,
    EVOLUTION,
    INCIDENT,
    RECIT,
    HORS_RECIT,
    HORS_RELEASE

}