export enum Resultat {
    KO ,
    OK ,
    Non_Teste,
    Abandonnes,
    Hors_Perimetre,
    En_Cours,
    Bloquee
}