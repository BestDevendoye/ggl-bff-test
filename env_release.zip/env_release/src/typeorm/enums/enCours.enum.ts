export enum EnCours {
    A_TRAITES,
    CORRIGEES,
    VERIFICATION,
    EVOLUTION
}