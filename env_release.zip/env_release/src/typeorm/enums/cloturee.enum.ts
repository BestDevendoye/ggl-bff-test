export enum Cloturee {
    ValidationCorrectifs,
    Rejetees,
    ProblemeDocumentaire,
    ArbitrageProjetEvolution
}