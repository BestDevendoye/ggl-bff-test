export enum Criticite {
    BLOQUANTE,
    MINEURE,
    MAJEURE
}